{{--   <?php echo '<br>';
   var_dump(session()->all()); 
   ?> --}}
@extends('master')
@section('content')
  <h1>All posts</h1>
  
  <a href="{{$url}}" class="btn btn-primary">Sign In with Twitter</a>



  <table  class='table table-striped'>
      <tr>
        <th>Tw ID</th>
        <th>Username</th>
        <th>Remove</th>
      </tr>
      @foreach($twitterAccounts as $twitterAccount)
      <tr>
        <td>{{$twitterAccount->twitter_uid}}</td>
        <td><a href="https://twitter.com/{{$twitterAccount->twitter_username}}">
          <img src="{{$twitterAccount->profile_image_url}}"> {{$twitterAccount->twitter_username}}
          </a>
        </td>
      </tr>
      @endforeach
    </table>
  

@endsection
