<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\TwitterAccount;

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

use Abraham\TwitterOAuth\TwitterOAuth;

class TwitterAccountController extends Controller
{
    const CONSUMER_KEY = 'NyIjoaYP1nX9qTEYGwGevxQdF';
    const CONSUMER_SECRET = 'ukpm8N2Vgdwx97eozKx4QSxil4hyUy9eHRMMTEjKxX34qNTnl0';
    const OAUTH_CALLBACK = 'http://twcallback.com/callback';

    public function __construct () {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function index()
    {
        $twitterAccounts = TwitterAccount::orderBy('id', 'desc')
                            ->where('userID', Auth::id())
                            ->get();

        // if(!Session::has('access_token')){

            $connection = new TwitterOAuth(self::CONSUMER_KEY,self::CONSUMER_SECRET);
            $request_token = $connection->oauth('oauth/request_token', array('oauth_callback' => 
                self::OAUTH_CALLBACK));
            Session::put('oauth_token', $request_token['oauth_token']);
            Session::put('oauth_token_secret', $request_token['oauth_token_secret']);
            $url = $connection->url('oauth/authorize', array('oauth_token' => $request_token['oauth_token']));
            return view('twitterAccount.index')
                            ->with('url', $url)
                            ->with('twitterAccounts', $twitterAccounts);
           
        // } else{
        //     $access_token = Session::get('access_token');
        //     $connection = new TwitterOAuth(
        //         self::CONSUMER_KEY, 
        //         self::CONSUMER_SECRET, 
        //         $access_token['oauth_token'], 
        //         $access_token['oauth_token_secret']);
        //     $user = $connection->get("account/verify_credentials");
        //     return $user->screen_name;
        // }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('twitterAccount.create');
    }
    public function callback(Request $request)
    {
        
        if ($request->has('oauth_verifier') && 
            $request->has('oauth_token')  && 
            $request['oauth_token'] == Session::get('oauth_token')) {


            $request_token = [];
            $request_token['oauth_token'] = Session::get('oauth_token');
            $request_token['oauth_token_secret'] = Session::get('oauth_token_secret');

            $connection = new TwitterOAuth(self::CONSUMER_KEY, self::CONSUMER_SECRET, $request_token['oauth_token'], $request_token['oauth_token_secret']);

            $access_token = $connection->oauth("oauth/access_token", array(
                "oauth_verifier" => $request['oauth_verifier']));

            $connection = new TwitterOAuth(
                self::CONSUMER_KEY, 
                self::CONSUMER_SECRET, 
                $access_token['oauth_token'], 
                $access_token['oauth_token_secret']);
            $user = $connection->get("account/verify_credentials");

            $twitterAccount = TwitterAccount::updateOrCreate(
                ['twitter_uid' => $user->id_str],
                ['userID' => Auth::id(), 'twitter_username' => $user->screen_name,
                'Active' => 1,
                    'Access_Token' => $request_token['oauth_token'],
                    'Access_Token_Secret' => $request_token['oauth_token_secret'],
                    'profile_image_url' => $user->profile_image_url
                ]
            );

            Session::put('access_token', $access_token);
            return redirect()->route('twitter');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        return view('twitterAccount.show', ['post' => $post]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        $post->delete();
        return redirect(route('posts.index'));
    }
}
