<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBountyListTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bounty_list', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('twitter_account_id');
            $table->string('bounty_username');
            $table->integer('bounty_uid');
            $table->integer('number_of_retweet');
            $table->integer('number_of_tweet');
            $table->string('tweet_keyword');
            $table->integer('number_of_tweet_with_quote');
            $table->string('tweet_with_quote_keyword');
            $table->integer('comment_enabled');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bounty_list');
    }
}
