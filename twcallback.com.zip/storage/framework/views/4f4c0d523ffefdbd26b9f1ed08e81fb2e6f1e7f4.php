<?php $__env->startSection('content'); ?>
  <h1>All posts</h1>
  <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">Create Post</a>
  <div style="height: 50px;"></div>
  <table  class='table table-striped'>
    <tr>
      <th>Title</th>
      <th>Edit</th>
      <th>Remove</th>
    </tr>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><a href="<?php echo e(route('posts.show', $post->id)); ?>">
          <?php echo e($post->title); ?>

        </a></td>
      <td> <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info">Edit</a></td>
      <td><form onsubmit="return confirm('Are you sure you want to delete this post?')" class="d-inline-block" method="post" action="<?php echo e(route('posts.destroy', $post->id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button type="submit" class="btn btn-danger">Delete</button>
        </form></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  
  
  
  <div class="mt-4">
    <?php echo e($posts->links()); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>