<?php $__env->startSection('content'); ?>
<h2 class="my-3">Update the post</h2>
<?php if($errors->all()): ?>
  <div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>

<?php if(session()->has('message')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('message')); ?>

  </div>
<?php endif; ?>

<form action="<?php echo e(route('posts.update', $post->id)); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
  <div class="form-group">
    <label for="title">Title</label>
    <input type="text" name="title" id="title" class="form-control" value='<?php echo e($post->title); ?>'>
  </div>
  <div class="form-group">
    <label for="content">Content</label>
    <textarea name="content" id="content" cols="30" rows="10" class="form-control"><?php echo e($post->content); ?></textarea>
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-outline-info">update the post</button>
  </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>