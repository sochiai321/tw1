<?php $__env->startSection('content'); ?>
  <h1>All posts</h1>
  
  <?php echo e($TwitterAccounts); ?>

  
  
  <div class="mt-4">

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>