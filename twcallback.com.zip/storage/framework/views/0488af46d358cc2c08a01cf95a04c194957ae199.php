{{--   <?php echo '<br>';
   var_dump(session()->all()); 
   ?> --}}

<?php $__env->startSection('content'); ?>
  <h1>All posts</h1>
  
  <a href="<?php echo e($url); ?>" class="btn btn-primary">Sign In with Twitter</a>



  <table  class='table table-striped'>
      <tr>
        <th>Tw ID</th>
        <th>Username</th>
        <th>Remove</th>
      </tr>
      <?php $__currentLoopData = $twitterAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twitterAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($twitterAccount->twitter_uid); ?></td>
        <td><a href="https://twitter.com/<?php echo e($twitterAccount->twitter_username); ?>">
          <img src="<?php echo e($twitterAccount->profile_image_url); ?>"> <?php echo e($twitterAccount->twitter_username); ?>

          </a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>